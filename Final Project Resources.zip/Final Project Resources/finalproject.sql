/* CREATE DATABASE [finalProject]
GO
USE [finalProject]
GO

CREATE TABLE [dbo].[Customers](
	[CustomerID] [int] NOT NULL PRIMARY KEY,
	[CustomerFirstName] [varchar](50) NULL,
	[CustomerLastName] [varchar](50) NULL,
	[CustomerPhone] [int] NULL
 );
GO
CREATE TABLE [dbo].[Food](
	[FoodID] [int] NOT NULL PRIMARY KEY,
	[FoodDescription] [varchar](30) NULL,
	[Price] [int] NULL
);
GO
CREATE TABLE [dbo].[OrderDetail](
	[OrderID] [int] NOT NULL PRIMARY KEY,
	[FoodID] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[Price] [int] NOT NULL,
	[OrdID] [int] NOT NULL
 );
GO
CREATE TABLE [dbo].[Orders](
	[OrderID] [int] NOT NULL PRIMARY KEY,
	[CustomerID] [int] NOT NULL,
	[RestaurantID] [int] NOT NULL
 );
GO
CREATE TABLE [dbo].[Ratings](
	[ReviewID] [int] NOT NULL PRIMARY KEY,
	[RestaurantID] [int] NOT NULL,
	[RestaurantRating] [int] NULL,
	[Comments] [varchar](50) NULL
 );
GO

CREATE TABLE [dbo].[Restaurants](
	[RestaurantID] [int] NOT NULL PRIMARY KEY,
	[RestaurantName] [varchar](50) NULL,
	[RestaurantLocation] [varchar](50) NULL,
	[Zipcode] [int] NULL
 );
GO
CREATE TABLE [dbo].[Zipcodes](
	[Zipcode] [int] NOT NULL PRIMARY KEY,
	[City] [varchar](30) NULL,
	[State] [nchar](10) NULL
 );


USE finalProject;

ALTER TABLE [dbo].[OrderDetail]   ADD  CONSTRAINT [FK_FoodID] FOREIGN KEY([FoodID])
REFERENCES [dbo].[Food] ([FoodID])
GO
ALTER TABLE [dbo].[Orders]   ADD  CONSTRAINT [FK_CustomerID] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Customers] ([CustomerID])
GO
ALTER TABLE [dbo].[Orders] ADD  CONSTRAINT [FK_RestaurantID] FOREIGN KEY([RestaurantID])
REFERENCES [dbo].[Restaurants] ([RestaurantID])
GO

ALTER TABLE [dbo].[Ratings]  ADD  CONSTRAINT [FK_Ratings_RestaurantID] FOREIGN KEY([RestaurantID])
REFERENCES [dbo].[Restaurants] ([RestaurantID])
GO

ALTER TABLE [dbo].[Restaurants]  ADD  CONSTRAINT [FK_Zipcode] FOREIGN KEY([Zipcode])
REFERENCES [dbo].[Zipcodes] ([Zipcode])
GO

ALTER TABLE [dbo].[OrderDetail]  ADD  CONSTRAINT [FK_ID] FOREIGN KEY(OrdID)
REFERENCES [dbo].[Orders] ([OrderID]);

ALTER TABLE [dbo].[OrderDetail]  ADD  CONSTRAINT [FK_ID] FOREIGN KEY(OrdID)
REFERENCES [dbo].[Orders] ([OrderID]);

INSERT INTO Customers VALUES('1', 'Spongebob', 'Squarepants',NULL)
INSERT INTO Customers VALUES('2', 'Patrick', 'Star',NULL)
INSERT INTO Customers VALUES('3', 'Squidward', 'Tentacles',NULL)
INSERT INTO Customers VALUES('4', 'Sandy', 'Cheeks',NULL)
INSERT INTO Customers VALUES('5', 'Shaggy', 'Rogers',NULL)
INSERT INTO Customers VALUES('6', 'Velma', 'Dinkley',NULL)
INSERT INTO Customers VALUES('7', 'Fred', 'Jones',NULL)
INSERT INTO Customers VALUES('8', 'Daphne', 'Blake',NULL)
INSERT INTO Customers VALUES('9', 'Bart', 'Simpson',NULL)
INSERT INTO Customers VALUES('10', 'Lisa', 'Simpson',NULL)

INSERT INTO Food VALUES('1', 'Pizza', 10)
INSERT INTO Food VALUES('2', 'Burger', 5)
INSERT INTO Food VALUES('3', 'Salad', 8)
INSERT INTO Food VALUES('4', 'Steak', 30)
INSERT INTO Food VALUES('5', 'Pancakes', 8)
INSERT INTO Food VALUES('6', 'Chicken Tenders', 9)
INSERT INTO Food VALUES('7', 'Prime Rib', 20)

INSERT INTO Zipcodes VALUES (49696, 'Traverse City', 'MI')
INSERT INTO Zipcodes VALUES (49686, 'Traverse City', 'MI')
INSERT INTO Zipcodes VALUES (49610, 'Acme', 'MI')
INSERT INTO Zipcodes VALUES (49690, 'Williamsburg', 'MI')
INSERT INTO Zipcodes VALUES (49682, 'Suttons Bay', 'MI')

INSERT INTO Restaurants VALUES('1', 'Thatsa Pizza', '110 Munson Ave', '49696')
INSERT INTO Restaurants VALUES('2', 'Applenees', '2384 US-31 S', '49686')
INSERT INTO Restaurants VALUES('3', 'Olive Garden', '2800 US-31', '49610')
INSERT INTO Restaurants VALUES('4', 'Outback Steak House', '3501 Marketplace Cir', '49690')
INSERT INTO Restaurants VALUES('5', 'Dennys', '878 Munson Ave', '49682') 

INSERT INTO Ratings VALUES(1, 1, 4, 'Pizza was great! Pepperoni could have been spicier.')
INSERT INTO Ratings VALUES(2, 2, 4, 'Burger needed more lettuce, but still tasted alright!')
INSERT INTO Ratings VALUES(3, 3, 4, 'Delicious salad and healthy too, could have used more croutons.')
INSERT INTO Ratings VALUES(4, 4, 4, 'Loved the steak, my compliments to the chef, even if my soda was flat.')
INSERT INTO Ratings VALUES(6, 5, 3, 'Pancakes were too soft, the bacon and coffee was nice though.')

INSERT INTO OrderDetail VALUES(1, 1, 1, 10)
INSERT INTO OrderDetail VALUES(2, 2, 4, 20)
INSERT INTO OrderDetail VALUES(3, 3, 2, 16)
INSERT INTO OrderDetail VALUES(4, 4, 1, 30)
INSERT INTO OrderDetail VALUES(5, 2, 3, 15)
INSERT INTO OrderDetail VALUES(6, 5, 1, 10)
INSERT INTO OrderDetail VALUES(7, 1, 2, 10)
INSERT INTO OrderDetail VALUES(8, 3, 1, 10)
INSERT INTO OrderDetail VALUES(9, 6, 2, 10)
INSERT INTO OrderDetail VALUES(10, 7, 1, 10) */

INSERT INTO Orders VALUES('1', '1', '1')
INSERT INTO Orders VALUES('2', '2', '2')
INSERT INTO Orders VALUES('3', '3', '3')
INSERT INTO Orders VALUES('4', '4', '4')
INSERT INTO Orders VALUES('5', '5', '5')
INSERT INTO Orders VALUES('6', '6', '6')
INSERT INTO Orders VALUES('7', '7', '1')
INSERT INTO Orders VALUES('8', '8', '3')
INSERT INTO Orders VALUES('9', '9', '2')
INSERT INTO Orders VALUES('10', '10', '4')

INSERT INTO Food VALUES(1, 'Pizza', 10)
INSERT INTO Food VALUES(2, 'Burger', 5)
INSERT INTO Food VALUES(3, 'Salad', 8)
INSERT INTO Food VALUES(4, 'Steak', 30)
INSERT INTO Food VALUES(5, 'Pancakes', 8)
INSERT INTO Food VALUES(6, 'Chicken Tenders', 9)
INSERT INTO Food VALUES(7, 'Prime Rib', 20)