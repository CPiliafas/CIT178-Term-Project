/* Final Project Views 
-- Read Only View

USE finalProject;
GO
CREATE VIEW FoodDescription_Read_Only
WITH ENCRYPTION
AS
SELECT FoodID, FoodDescription, Price
FROM Food;
GO
SELECT * FROM FoodDescription_Read_Only;
GO 

-- Update View
USE finalProject;
GO
CREATE VIEW FoodDescription_Update
WITH ENCRYPTION
AS
SELECT FoodID, FoodDescription, Price
FROM Food;
GO
SELECT * FROM FoodDescription_Update; 
GO

--Editing Row using view
USE finalProject;
GO
SELECT * FROM FoodDescription_Update;
GO
UPDATE FoodDescription_Update
SET Price=200
WHERE FoodID=1 AND FoodDescription=1;
GO
SELECT * FROM FoodDescription_Update;
GO


--  View with multiple tables
USE finalProject;
GO
CREATE VIEW RestaurantsView
AS
SELECT RestaurantID, 
FROM Customers JOIN Orders ON Customers.CustomerID = Orders.CustomerID;
GO
SELECT * FROM RestaurantsView;
GO

-- System catalog of views
SELECT [name], create_date, modify_date FROM sys.views;
*/